import java.io.IOException;
import java.util.*;

public class BinaryRetrieval {

    BinaryRetrieval() throws IOException {
            DictionaryInverted myDictionary = new DictionaryInverted();
        while (true) {
            Scanner scanner = new Scanner(System.in);
            System.out.println("PRINT YOUR QUERY:");
            String request = scanner.nextLine();
            int length = myDictionary.dict.length();
            int position = length / 2;
            int diviser = position;
            String answer = "";
            while (position > 0 && position < length) {
                while (!Character.isDigit(myDictionary.dict.charAt(position)))
                    position--;
                char ch = myDictionary.dict.charAt(position);
                if (position > 1)
                    if (!Character.isDigit(myDictionary.dict.charAt(position - 1)))
                        answer = myDictionary.dict.substring(position + 1, position + 1 + Character.getNumericValue(ch));
                    else {
                        answer = myDictionary.dict.substring(position + 1, position + 1 +
                                Integer.parseInt(myDictionary.dict.substring(position - 1, position + 1)));
                        position--;
                    }
                diviser /= 2;
                if (answer.compareTo(request) > 0) position -= diviser;
                if (answer.compareTo(request) < 0) position += diviser;
                if (answer.compareTo(request) == 0) break;
                if (diviser == 0) {
                    position += 10;
                    diviser = position / 2;
                }
                answer = "";
            }
            if (answer.equals(""))
                System.out.println("NO DOCS FOUND");
            else {
                System.out.println(myDictionary.positions.get(position));
            }
            System.out.println();
        }
    }

    public static void main(String[] args) throws IOException {
        BinaryRetrieval binaryRetrieval = new BinaryRetrieval();
    }

}
