import java.io.*;
import java.util.*;

//Попова Аліса, ІПЗ-2, 4 група

public class DictionaryInverted {

    TreeMap<String, TreeSet<Integer>> dictionary;
    TreeMap<Integer, TreeSet<Integer>> positions;
    private int wordsInCollection;
    private int wordsInDictionary;
    private int sizeCollection;
    public String dict = "";
    private long sizeDictionary;
    File[] textFiles;

    DictionaryInverted() throws IOException {
        dictionary = new TreeMap<>();
        wordsInCollection = 0;
        wordsInDictionary = 0;
        sizeCollection = 0;
        sizeDictionary = 0;

        textFiles = new File[10];
        textFiles[0] = new File("files/Alice In Wonderland.txt");
        textFiles[1] = new File("files/Dubliners.txt");
        textFiles[2] = new File("files/Grimm's Fairytales.txt");
        textFiles[3] = new File("files/Mockingjay.txt");
        textFiles[4] = new File("files/Peter Pan.txt");
        textFiles[5] = new File("files/Pride And Prejudice.txt");
        textFiles[6] = new File("files/The Adventures of Sherlock Holmes.txt");
        textFiles[7] = new File("files/The Picture Of Dorian Gray.txt");
        textFiles[8] = new File("files/Jane Eyre.txt");
        textFiles[9] = new File("files/The Awakening.txt");

        dictionary = new TreeMap<>();
        positions = new TreeMap<>();
        buildDictionary();
    }

    public void buildDictionary() throws IOException {
        for (int i = 0; i < textFiles.length; i++) {
            sizeCollection += textFiles[i].length();
            BufferedReader bufferedReader = new BufferedReader(new FileReader(textFiles[i].getAbsolutePath()));
            String s = "";
            while ((s = bufferedReader.readLine()) != null) {
                StringTokenizer stringTokenizer = new StringTokenizer(s, ".,:;()[]{}<>_- —=+“”'`\"/|!?$^&*@#%0123456789");
                while (stringTokenizer.hasMoreTokens()) {
                    String word = stringTokenizer.nextToken().toLowerCase();
                    wordsInCollection++;
                    TreeSet<Integer> setOfIndices = new TreeSet<>();
                    setOfIndices.add(i);
                    if (dictionary.containsKey(word)) {
                        setOfIndices = dictionary.get(word);
                        setOfIndices.add(i);
                        dictionary.put(word, setOfIndices);
                        continue;
                    }
                    dictionary.put(word, setOfIndices);
                }
            }
            bufferedReader.close();
        }
        wordsInDictionary = dictionary.size();
        PrintWriter printWriter = new PrintWriter(new BufferedWriter(new FileWriter("dictionaryInverted.txt")));
        PrintWriter printWriterStr = new PrintWriter(new BufferedWriter(new FileWriter("dictionaryString.txt")));
        printWriter.write("COLLECTION SIZE: " + sizeCollection + " bytes \n");
        printWriter.write("WORDS IN COLLECTION: " + wordsInCollection + "\n");
        printWriter.write("WORDS IN DICTIONARY: " + wordsInDictionary + "\n");
        printWriter.write("\n \n");
        Set keys = dictionary.keySet();
        int position = 0;
        int lengthOfString = 1;
        for (Iterator iterator = keys.iterator(); iterator.hasNext(); ) {
            String key = (String) iterator.next();
            positions.put(position, dictionary.get(key));
            if (key.toString().length() > 9) lengthOfString = 2;
            position += lengthOfString + key.toString().length();
            lengthOfString = 1;
            TreeSet<Integer> value = dictionary.get(key);
            printWriter.printf(key + "\t" + value + "\n");
            dict += key.length() + key;
        }
        printWriter.close();
        printWriterStr.write(dict);
        printWriterStr.close();
        File output = new File("dictionaryInverted.txt");
        sizeDictionary = output.length();
        PrintWriter out = new PrintWriter(new BufferedWriter(new FileWriter("dictionaryInverted.txt", true)));
        out.println("\nDICTIONARY SIZE: " + sizeDictionary + " bytes \n");
        out.flush();
        out.close();
    }


    public static void main(String[] args) throws IOException {
        DictionaryInverted dictionary = new DictionaryInverted();
    }

}
