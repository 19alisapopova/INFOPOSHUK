import javax.swing.tree.TreeModel;
import java.io.*;
import java.util.*;

//Попова Аліса, ІПЗ-2, 4 група

public class Dictionary {

    ArrayList<File> textFiles; //
    TreeMap<String, TreeMap<Integer, Integer>> dictionary; //
    private ArrayList<Integer> filesLength; //
    private TreeMap<String, Integer>[] fileTrees;
    static int averageSize = 0;
    private int wordsInCollection;
    private int wordsInDictionary;

    Dictionary() throws IOException {
        dictionary = new TreeMap<>();
        wordsInCollection = 0;
        wordsInDictionary = 0;

        textFiles = new ArrayList<>();
        textFiles.add(new File("files/Alice In Wonderland.txt"));
        textFiles.add(new File("files/Dubliners.txt"));
        textFiles.add(new File("files/Grimm's Fairytales.txt"));
        textFiles.add(new File("files/Mockingjay.txt"));
        textFiles.add(new File("files/Peter Pan.txt"));
        textFiles.add(new File("files/Pride And Prejudice.txt"));
        textFiles.add(new File("files/The Adventures of Sherlock Holmes.txt"));
        textFiles.add(new File("files/The Picture Of Dorian Gray.txt"));
        textFiles.add(new File("files/Jane Eyre.txt"));
        textFiles.add(new File("files/The Awakening.txt"));
        dictionary = new TreeMap<>();
        filesLength = new ArrayList<>();
        fileTrees = new TreeMap[10];
        buildDictionary();
    }

    public void buildDictionary() throws IOException {
        for (int i = 0; i < textFiles.size(); i++) {
            fileTrees[i]= new TreeMap<>();
            int lengthOfFile = 0;
            BufferedReader bufferedReader = new BufferedReader(new FileReader(textFiles.get(i).getAbsolutePath()));
            String s = "";
            while ((s = bufferedReader.readLine()) != null) {
                StringTokenizer stringTokenizer = new StringTokenizer(s, ".,:;()[]{}<>_- —=+“”'`\"/|!?$^&*@#%0123456789");
                while (stringTokenizer.hasMoreTokens()) {
                    lengthOfFile++;
                    wordsInCollection++;
                    String word = stringTokenizer.nextToken().toLowerCase();
                    TreeMap<Integer, Integer> mapDocFrequency = new TreeMap<>();
                    mapDocFrequency.put(i, 1);
                    int frequency = 1;
                    if (dictionary.containsKey(word)) {
                        mapDocFrequency = dictionary.get(word);
                        if (mapDocFrequency.containsKey(i)) {
                            frequency = mapDocFrequency.get(i);
                            frequency++;
                            mapDocFrequency.put(i, frequency);
                        } else {
                            mapDocFrequency.put(i, 1);
                        }
                    }
                    fileTrees[i].put(word, frequency);
                    dictionary.put(word, mapDocFrequency);
                }
            }
            filesLength.add(lengthOfFile);
            bufferedReader.close();
        }
        for (Integer i: filesLength) {
            averageSize += i;
        }
        averageSize /= 10;
        wordsInDictionary = dictionary.size();
        PrintWriter printWriter = new PrintWriter(new BufferedWriter(new FileWriter("dictionaryInverted.txt")));
        printWriter.write("WORDS IN COLLECTION: " + wordsInCollection + "\n");
        printWriter.write("WORDS IN DICTIONARY: " + wordsInDictionary + "\n");
        printWriter.write("\n \n");
        Set keys = dictionary.keySet();
        for (Iterator iterator = keys.iterator(); iterator.hasNext(); ) {
            String key = (String) iterator.next();
            TreeMap<Integer, Integer> value = dictionary.get(key);
            printWriter.printf(key + "\t" + value + "\n");
        }
        printWriter.close();

        PrintWriter printWriter1 = new PrintWriter(new BufferedWriter(new FileWriter("dictionaryEach.txt")));
        for (TreeMap<String, Integer> t: fileTrees) {
            Set keys1 = t.keySet();
            for (Iterator iterator = keys1.iterator(); iterator.hasNext(); ) {
                String key = (String) iterator.next();
                Integer value = t.get(key);
                printWriter1.printf(key + "\t" + value + "\n");
            }
        }
        printWriter1.close();
    }


    public static void main(String[] args) throws IOException {
        Dictionary dictionary = new Dictionary();
        BM25 bm25 = new BM25();
        while (true) {
            Scanner scanner = new Scanner(System.in);
            System.out.println("Type a string: ");
            String request = scanner.nextLine();
            if (request.length() < 1) System.out.println("Empty request, all documents are relevant.");
            else {
                request = request.toLowerCase();
                for (int i = 0; i < 10; i++) {
                    if (dictionary.fileTrees[i].get(request) == null || dictionary.dictionary.get(request) == null)
                        System.out.println("Revelance of doc #" + i + " - " + 0);
                    else
                        System.out.println("Revelance of doc #" + i + " - " + bm25.rank(dictionary.textFiles, dictionary.filesLength.get(i), request, dictionary.fileTrees[i].get(request), dictionary.dictionary.get(request).size()));
                }
            }
            System.out.println();
        }
    }

}
