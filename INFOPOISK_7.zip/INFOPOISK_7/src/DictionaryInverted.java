import java.io.*;
import java.math.BigDecimal;
import java.util.*;

import com.kursx.parser.fb2.*;

//Попова Аліса, ІПЗ-2, 4 група

public class DictionaryInverted {

    TreeMap<String, TreeMap<String, TreeSet<Integer>>> dictionary;
    private int wordsInCollection;
    private int wordsInDictionary;
    private int sizeCollection;
    private long sizeDictionary;
    File[] textFiles;

    DictionaryInverted() throws Exception {
        dictionary = new TreeMap<>();
        wordsInCollection = 0;
        wordsInDictionary = 0;
        sizeCollection = 0;
        sizeDictionary = 0;

        textFiles = new File[10];
        textFiles[0] = new File("files/1984-George_Orwell.fb2");
        textFiles[1] = new File("files/Between_Two_Worlds-Stephen_Rabley.fb2");
        textFiles[2] = new File("files/Black_Cat-Edgar_Allan_Poe.fb2");
        textFiles[3] = new File("files/Dracula-Bram_Stoker.fb2");
        textFiles[4] = new File("files/Forrest_Gump-John_Escott.fb2");
        textFiles[5] = new File("files/Sleeping_Beauty-Charles_Perrault.fb2");
        textFiles[6] = new File("files/The_Facts_in_The_Case_of_Mr_Valdemar-Edgar_Allan_Poe.fb2");
        textFiles[7] = new File("files/The_Lady_or_the_Tiger-Frank_Stockton.fb2");
        textFiles[8] = new File("files/The_Picture_of_Dorian_Gray-Oscar_Wilde.fb2");
        textFiles[9] = new File("files/Titanic-Tim_Vicary.fb2");

        dictionary = new TreeMap<>();
        buildDictionary();
    }

    public void buildDictionary() throws Exception {
        for (int i = 0; i < textFiles.length; i++) {
            sizeCollection += textFiles[i].length();
            FictionBook fictionBook = new FictionBook(textFiles[i]);

            for (Person person : fictionBook.getAuthors()) {
                String author = person.getFullName();
                StringTokenizer stringTokenizer = new StringTokenizer(author);
                while (stringTokenizer.hasMoreTokens()) {
                    wordsInCollection++;
                    String s = stringTokenizer.nextToken().toLowerCase();
                    TreeMap<String, TreeSet<Integer>> wordMap = dictionary.get(s);
                    if (wordMap == null) {
                        wordMap = new TreeMap<>();
                    }
                    TreeSet<Integer> setOfIndices = wordMap.get("author");
                    if (setOfIndices == null) {
                        setOfIndices = new TreeSet<>();
                    }
                    setOfIndices.add(i);
                    wordMap.put("author", setOfIndices);
                    dictionary.put(s, wordMap);
                }
            }

            String title = fictionBook.getTitle();
            StringTokenizer stringTokenizer = new StringTokenizer(title);
            while (stringTokenizer.hasMoreTokens()) {
                wordsInCollection++;
                String s = stringTokenizer.nextToken().toLowerCase();
                TreeMap<String, TreeSet<Integer>> wordMap = dictionary.get(s);
                if (wordMap == null) {
                    wordMap = new TreeMap<>();
                }
                TreeSet<Integer> setOfIndices = wordMap.get("title");
                if (setOfIndices == null) {
                    setOfIndices = new TreeSet<>();
                }
                setOfIndices.add(i);
                wordMap.put("title", setOfIndices);
                dictionary.put(s, wordMap);
            }

            for (Section section : fictionBook.getBody().getSections()) {
                for (Element element : section.getElements()) {
                    String text = element.getText();
                    stringTokenizer = new StringTokenizer(text, ".,:;()[]{}<>_- —=+“”'`\"/|!?$^&*@#%0123456789");
                    while (stringTokenizer.hasMoreTokens()) {
                        wordsInCollection++;
                        String s = stringTokenizer.nextToken().toLowerCase();
                        TreeMap<String, TreeSet<Integer>> wordMap = dictionary.get(s);
                        if (wordMap == null) {
                            wordMap = new TreeMap<>();
                        }
                        TreeSet<Integer> setOfIndices = wordMap.get("body");
                        if (setOfIndices == null) {
                            setOfIndices = new TreeSet<>();
                        }
                        setOfIndices.add(i);
                        wordMap.put("body", setOfIndices);
                        dictionary.put(s, wordMap);
                    }
                }
            }

        }
        wordsInDictionary = dictionary.size();
        PrintWriter printWriter = new PrintWriter(new BufferedWriter(new FileWriter("dictionaryInverted.txt")));
        printWriter.write("COLLECTION SIZE: " + sizeCollection + " bytes \n");
        printWriter.write("WORDS IN COLLECTION: " + wordsInCollection + "\n");
        printWriter.write("WORDS IN DICTIONARY: " + wordsInDictionary + "\n");
        printWriter.write("\n \n");
        for (String word : dictionary.keySet()) {
            printWriter.println(word);
            for (String group : dictionary.get(word).keySet()) {
                printWriter.println("   " + group + "      " + dictionary.get(word).get(group));
            }
        }
        printWriter.close();
        File output = new File("dictionaryInverted.txt");
        sizeDictionary = output.length();
        PrintWriter out = new PrintWriter(new BufferedWriter(new FileWriter("dictionaryInverted.txt", true)));
        out.println("\nDICTIONARY SIZE: " + sizeDictionary + " bytes \n");
        out.flush();
        out.close();
    }

    public void search(String title, String author, String body) {
        ArrayList<Integer> authorDocs = new ArrayList<>();
        ArrayList<Integer> titleDocs = new ArrayList<>();
        ArrayList<Integer> bodyDocs = new ArrayList<>();

        try {
            if (title.equals("")) {
                for (int i = 0; i < textFiles.length; i++) {
                    titleDocs.add(i);
                }
            }
            else {
                for (Integer docID : dictionary.get(title).get("title")) {
                    titleDocs.add(docID);
                }
            }

            if (author.equals("")) {
                for (int i = 0; i < textFiles.length; i++) {
                    authorDocs.add(i);
                }
            }
            else {
                for (Integer docID : dictionary.get(author).get("author")) {
                    authorDocs.add(docID);
                }
            }
            if (body.equals("")) {
                for (int i = 0; i < textFiles.length; i++) {
                    bodyDocs.add(i);
                }
            }
            else {
                for (Integer docID : dictionary.get(body).get("body")) {
                    bodyDocs.add(docID);
                }
            }
        } catch(NullPointerException e){
            System.out.println("NO DOCS FOUND.");
        }


        TreeMap<Integer, BigDecimal> map = new TreeMap<>();

        for (Integer docID: authorDocs) {
            map.putIfAbsent(docID, BigDecimal.valueOf(0.0));
            map.put(docID, map.get(docID).add(BigDecimal.valueOf(0.3)));
        }
        for (Integer docID: titleDocs) {
            map.putIfAbsent(docID, BigDecimal.valueOf(0.0));
            map.put(docID, map.get(docID).add(BigDecimal.valueOf(0.6)));
        }
        for (Integer docID: bodyDocs) {
            map.putIfAbsent(docID, BigDecimal.valueOf(0.0));
            map.put(docID, map.get(docID).add(BigDecimal.valueOf(0.1)));
        }

        BigDecimal[] values = {BigDecimal.valueOf(1.0), BigDecimal.valueOf(0.9), BigDecimal.valueOf(0.7), BigDecimal.valueOf(0.6),
                BigDecimal.valueOf(0.4), BigDecimal.valueOf(0.3), BigDecimal.valueOf(0.1)};

        for (BigDecimal value: values)
            for (Integer i: map.keySet())
                if (map.get(i).equals(value))
                    System.out.println(i + " " + map.get(i));

        System.out.println();
    }


    public static void main(String[] args) throws Exception {
        DictionaryInverted dictionary = new DictionaryInverted();
        while(true) {
            Scanner scanner = new Scanner(System.in);
            System.out.println("SEARCH");
            System.out.println("\nTITLE: ");
            String title = scanner.nextLine();
            System.out.println("\nAUTHOR: ");
            String author = scanner.nextLine();
            System.out.println("\nBODY: ");
            String body = scanner.nextLine();
            dictionary.search(title, author, body);
        }
    }

}
